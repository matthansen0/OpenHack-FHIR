package ca.uhn.hl7v2.hoh.encoder;

public enum TransferEncoding {

	CHUNKED

}
